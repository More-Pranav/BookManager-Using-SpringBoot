package com.SpringBootProject.BooksManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
